import User from "./User.ts";
import Message from "./Message.ts";
import Attachment from "./Attachment.ts";
import Chat from "./Chat.ts";
import File from "./File.ts";

User.hasMany(Message);
Message.belongsTo(User);

Message.hasMany(Attachment);
Attachment.belongsTo(Message);

User.hasMany(Chat);
Chat.belongsTo(User);

export { User, File };
