import { Model, DataTypes } from "sequelize";

import { sequelize } from "../utils/db.ts";

class Message extends Model {}

Message.init(
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
    },
    chatId: {
      type: DataTypes.STRING,
      references: {},
    },
    senderId: {
      type: DataTypes.STRING,
      references: {},
    },
    content: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    seen: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    reaction: {
      type: DataTypes.STRING,
    },
    deleted: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    replyTo: {
      type: DataTypes.STRING,
      references: {},
    },
    attachment: {
      type: DataTypes.STRING,
      references: {},
    },
  },
  { sequelize, underscored: true, modelName: "message" },
);

export default Message;
