import { Model, DataTypes } from "sequelize";
import { sequelize } from "../utils/db.ts";

class File extends Model {}

File.init(
  {
    fileId: {
      type: DataTypes.STRING,
      primaryKey: true,
    },
    uploadUrl: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    publicUrl: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
  },
  {
    sequelize,
    underscored: true,
    timestamps: false,
    modelName: "file",
  },
);

export default File;
