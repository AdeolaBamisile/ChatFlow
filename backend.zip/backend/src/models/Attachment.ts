import { Model, DataTypes } from "sequelize";
import { sequelize } from "../utils/db.ts";

class Attachment extends Model {}

Attachment.init(
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
    },
    type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    url: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING,
    },
    mimeType: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    size: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    duration: {
      type: DataTypes.INTEGER,
    },
    messageId: {
      type: DataTypes.STRING,
      references: {},
    },
  },
  { sequelize, underscored: true, modelName: "attchment" },
);

export default Attachment;
