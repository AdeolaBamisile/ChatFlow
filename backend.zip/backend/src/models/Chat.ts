import { Model, DataTypes } from "sequelize";
import { sequelize } from "../utils/db.ts";

class Chat extends Model {}

Chat.init(
  {
    id: {
      type: DataTypes.STRING,
      primaryKey: true,
    },
    friend: {
      type: DataTypes.STRING,
      references: {},
    },
    preview: {
      type: DataTypes.STRING,
    },
    lastMessageAt: {
      type: DataTypes.STRING,
    },
    unreadCount: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    muted: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    pinned: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    blockedByFriend: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
  },
  { sequelize, underscored: true, modelName: "chat" },
);

export default Chat;
