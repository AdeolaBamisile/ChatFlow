import dns from "node:dns/promises";

process.env.NODE_ENV !== "production" && dns.setServers(["8.8.8.8", "1.1.1.1"]);

import { PORT } from "./utils/config.ts";

import startServer from "./server.ts";
import { connectToDatabase } from "./utils/db.ts";

const main = async () => {
  await connectToDatabase();
  startServer(PORT!);
};

main();
