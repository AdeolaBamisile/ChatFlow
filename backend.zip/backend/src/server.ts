import express from "express";
import { WebSocketServer } from "ws";
import { useServer } from "graphql-ws/use/ws";
import { ApolloServer } from "@apollo/server";
import { ApolloServerPluginDrainHttpServer } from "@apollo/server/plugin/drainHttpServer";
import { expressMiddleware } from "@as-integrations/express5";
import { makeExecutableSchema } from "@graphql-tools/schema";
import http from "http";

import typeDefs from "./schema.ts";
import resolvers from "./resolvers.ts";
import jwt from "jsonwebtoken";
import { SECRET } from "./utils/config.ts";
import { User } from "./models/index.ts";

const getUserFromAuthHeader = async (auth?: string) => {
  if (!auth || !auth.toLowerCase().startsWith("bearer ")) {
    return null;
  }

  const decodedToken = String(jwt.verify(auth.substring(7), SECRET!));
  return User.findByPk(decodedToken);
};

const startServer = async (port: string) => {
  const app = express();
  const httpServer = http.createServer(app);

  const wsServer = new WebSocketServer({
    server: httpServer,
    path: "/",
  });

  const schema = makeExecutableSchema({ typeDefs, resolvers });
  const serverCleanup = useServer({ schema }, wsServer);

  const server = new ApolloServer({
    schema,
    plugins: [
      ApolloServerPluginDrainHttpServer({ httpServer }),
      {
        async serverWillStart() {
          return {
            async drainServer() {
              await serverCleanup.dispose();
            },
          };
        },
      },
    ],
  });

  await server.start();

  app.use(express.static("dist"));

  app.use(
    "/graphql",
    express.json(),
    expressMiddleware(server, {
      context: async ({ req }) => {
        const auth = req.headers.authorization;
        const currentUser = getUserFromAuthHeader(auth);
        return { currentUser };
      },
    }),
  );

  httpServer.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
};

export default startServer;
