export interface User {
  id: string;
  name: string;
  username: string;
  email?: string;
  avatar: string;
  bio: string;
  online: boolean;
  allowFriendRequests?: boolean;
}
