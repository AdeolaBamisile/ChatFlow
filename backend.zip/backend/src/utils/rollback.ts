import { rollbackMigrations } from "./db.ts";

rollbackMigrations();
