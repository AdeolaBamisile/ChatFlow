import { Sequelize } from "sequelize";
import { DATABASE } from "./config.ts";

import { SequelizeStorage, Umzug } from "umzug";

const sequelize = new Sequelize(DATABASE!, {
  dialect: "postgres",
  dialectOptions: {
    ssl: {
      require: true,
      rejectUnauthorized: false,
    },
  },
});

const migrationConfig = {
  migrations: { glob: "src/migrations/*ts" },
  storage: new SequelizeStorage({ sequelize, tableName: "migrations" }),
  context: sequelize.getQueryInterface(),
  logger: console,
};

const runMigrations = async () => {
  const migrator = new Umzug(migrationConfig);

  const migrations = await migrator.up();
  console.log("Migrations up uo date", {
    files: migrations.map((mig) => mig.name),
  });
};

export const rollbackMigrations = async () => {
  await sequelize.authenticate();
  const migratior = new Umzug(migrationConfig);
  await migratior.down();
};

const connectToDatabase = async () => {
  try {
    await sequelize.authenticate();
    await runMigrations();
    console.log("connected to database");
  } catch {
    console.error("Failed to connect to database");
    return process.exit(1);
  }
};

export { sequelize, connectToDatabase };
