import dotenv from "dotenv";
dotenv.config();

const PORT = process.env.PORT;

const SECRET = process.env.SECRET;

const GEMINI_KEY = process.env.GEMINI_KEY;

const DATABASE = process.env.DATABASE;

const SUPABASE_KEY = process.env.SUPABASE_KEY;
const SUPABASE_BUCKET = process.env.SUPABASE_BUCKET;
const SUPABASE_URL = process.env.SUPABASE_URL;

export {
  DATABASE,
  PORT,
  SECRET,
  GEMINI_KEY,
  SUPABASE_BUCKET,
  SUPABASE_KEY,
  SUPABASE_URL,
};
