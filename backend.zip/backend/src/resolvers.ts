import { v1 as uuid } from "uuid";
import { PubSub } from "graphql-subscriptions";
import { GraphQLError } from "graphql";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import { createClient } from "@supabase/supabase-js";
import multer from "multer";
import {
  SUPABASE_URL,
  SUPABASE_KEY,
  SUPABASE_BUCKET,
  GEMINI_KEY,
} from "./utils/config.ts";
import { File } from "./models/index.ts";
import { GoogleGenAI } from "@google/genai";

import type { User } from "./types.ts";

const pubsub = new PubSub();

const ai = new GoogleGenAI({ apiKey: GEMINI_KEY! });

const supabase = createClient(SUPABASE_URL!, SUPABASE_KEY!);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1025 * 1024 },
});

const resolvers = {
  Query: {},
  Mutation: {
    sendGeminiMessage: async (root, args, { currentUser }) => {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [...args],
      });

      return response;
    },
    prepareMediaUpload: async (_root, args, { currentUser }) => {
      const file = args.file;

      if (!file) {
        throw new GraphQLError("File not found");
      }

      const fileKey = `profilePicture/${crypto.randomUUID()}-${file.originalname}`;

      const { error: uploadError } = await supabase.storage
        .from(SUPABASE_BUCKET!)
        .upload(fileKey, file.buffer, {
          contentType: file.mimetype,
          upsert: false,
        });

      if (uploadError) {
        throw uploadError;
      }

      const { data: publicData } = supabase.storage
        .from(SUPABASE_BUCKET!)
        .getPublicUrl(fileKey);

      const mediaUrl = publicData.publicUrl;

      const saveRecord = await File.create({
        fileId: uuid(),
        uploadUrl: "",
        publicUrl: mediaUrl,
      });

      return saveRecord;
    },
  },
  Subscription: {},
};

export default resolvers;
